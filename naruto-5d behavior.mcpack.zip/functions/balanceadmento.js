function generatePlayerStatusTable(initialLife, maxLife, initialChakra, initialStamina, maxStamina) {
    let playerLevel = 1;
    let playerLife = initialLife;
    let playerChakra = initialChakra;
    let playerStamina = initialStamina;

    const table = [
        ['Level', 'Life', 'Total Life', 'Chakra', 'Stamina', 'Armor Defense']
    ];

    while (playerLife <= maxLife && playerChakra <= maxLife && playerStamina <= maxStamina) {
        let armorDefense;
        if (playerLevel >= 20 && playerLevel <= 40) {
            armorDefense = 1;
        } else if (playerLevel >= 41 && playerLevel <= 60) {
            armorDefense = 2;
        } else if (playerLevel >= 61 && playerLevel <= 80) {
            armorDefense = 3;
        } else if (playerLevel >= 81 && playerLevel <= 100) {
            armorDefense = 4;
        } else {
            armorDefense = 0;
        }

        const totalLife = playerLife * (1 + armorDefense * 0.2);

        table.push([
            playerLevel, playerLife, totalLife.toFixed(2), playerChakra, playerStamina, armorDefense
        ]);

        playerLevel++;
        playerLife += 10;
        playerChakra += 10;
        playerStamina += 10;
    }
    return table;
}

function generateEnemyBalancingTable(playerStatusTable, enemyType) {
    const table = [
        [`Enemy Level (${enemyType})`, `Enemy Life (${enemyType})`, `Enemy Damage (${enemyType})`]
    ];

    for (let enemyLevel = 1; enemyLevel <= 100; enemyLevel++) {
        let playerStats = playerStatusTable.find(row => row[0] === enemyLevel);
        if (!playerStats) {
            playerStats = playerStatusTable[playerStatusTable.length - 1];
        }

        const playerLevel = playerStats[0];
        const playerTotalLife = parseFloat(playerStats[2]);
        let enemyLife;
        let enemyDamage;

        switch (enemyType) {
            case "Weak":
                enemyLife = playerTotalLife / 2;
                enemyDamage = (playerLevel * 10) * (enemyLevel / playerLevel) * 0.2;
                break;
            case "Medium":
                enemyLife = playerTotalLife * 0.75;
                enemyDamage = (playerLevel * 12) * (enemyLevel / playerLevel) * 0.25;
                break;
            case "Mini-Boss":
                enemyLife = playerTotalLife * 1.5;
                enemyDamage = (playerLevel * 15) * (enemyLevel / playerLevel) * 0.3;
                break;
            case "Boss":
                enemyLife = playerTotalLife * 5;
                enemyDamage = (playerLevel * 20) * (enemyLevel / playerLevel) * 0.4;
                break;
            default:
                console.error("Invalid enemy type specified.");
                return;
        }

        table.push([enemyLevel, enemyLife.toFixed(2), enemyDamage.toFixed(2)]);
    }
    return table;
}

function generatePlayerDamageTable(playerStatusTable) {
    const playerDamageTable = [
        ['Level', 'Weapon Type', 'Cooldown', 'Damage', 'DPS']
    ];

    for (let playerLevel = 1; playerLevel <= 100; playerLevel++) {
        const playerStats = playerStatusTable.find(row => row[0] === playerLevel);
        if (!playerStats) {
            playerStats = playerStatusTable[playerStatusTable.length - 1];
        }

        const playerTotalLife = parseFloat(playerStats[2]);
        const heavyWeaponDamage = playerTotalLife / 5;
        const fastWeaponDamage = heavyWeaponDamage / 2;

        // Heavy Weapon Entry
        playerDamageTable.push([
            playerLevel,
            'Heavy Weapon',
            '1 second',
            heavyWeaponDamage.toFixed(2),
            heavyWeaponDamage.toFixed(2) // DPS is same as damage for 1 second cooldown
        ]);

        // Fast Weapon Entry
        playerDamageTable.push([
            playerLevel,
            'Fast Sword',
            '0.5 seconds',
            fastWeaponDamage.toFixed(2),
            (fastWeaponDamage * 2).toFixed(2) // DPS is double damage for 0.5 second cooldown
        ]);
    }

    return playerDamageTable;
}

// Nova função para gerar a tabela de balanceamento de jutsus
function generateJutsuBalancingTable(playerStatusTable) {
    const jutsuRanks = ["D", "C", "B", "A", "S"];
    const jutsuTable = [
        ['Level', 'Rank', 'Chakra Cost', 'Damage', 'Posture Damage', 'Cooldown (s)', 'Range (blocks)']
    ];

    // Definir valores para cada rank
    const rankValues = {
        "D": {
            chakraCostBase: 50,
            chakraCostScale: 0.5,
            damageInitial: 10,
            damageFinal: 100,
            postureDamageInitial: 5,
            postureDamageFinal: 50,
            cooldownMin: 3,
            cooldownMax: 5,
            rangeMin: 10,
            rangeMax: 15
        },
        "C": {
            chakraCostBase: 100,
            chakraCostScale: 1,
            damageInitial: 20,
            damageFinal: 150,
            postureDamageInitial: 10,
            postureDamageFinal: 75,
            cooldownMin: 5,
            cooldownMax: 8,
            rangeMin: 15,
            rangeMax: 20
        },
        "B": {
            chakraCostBase: 200,
            chakraCostScale: 1.5,
            damageInitial: 30,
            damageFinal: 200,
            postureDamageInitial: 15,
            postureDamageFinal: 100,
            cooldownMin: 8,
            cooldownMax: 12,
            rangeMin: 20,
            rangeMax: 25
        },
        "A": {
            chakraCostBase: 350,
            chakraCostScale: 1.5,
            damageInitial: 50,
            damageFinal: 300,
            postureDamageInitial: 25,
            postureDamageFinal: 150,
            cooldownMin: 12,
            cooldownMax: 20,
            rangeMin: 25,
            rangeMax: 30
        },
        "S": {
            chakraCostBase: 500,
            chakraCostScale: 2,
            damageInitial: 80,
            damageFinal: 450,
            postureDamageInitial: 40,
            postureDamageFinal: 225,
            cooldownMin: 20,
            cooldownMax: 30,
            rangeMin: 30,
            rangeMax: 40
        }
    };

    // Níveis em que cada rank se torna disponível
    const rankLevelRequirements = {
        "D": 1,
        "C": 21,
        "B": 41,
        "A": 61,
        "S": 81
    };

    // Gerar tabela para cada nível de jogador
    for (let playerLevel = 1; playerLevel <= 100; playerLevel++) {
        // Obter estatísticas do jogador para este nível
        const playerStats = playerStatusTable.find(row => row[0] === playerLevel);
        if (!playerStats) continue;

        const playerChakra = playerStats[3]; // Chakra do jogador neste nível

        // Para cada rank que está disponível neste nível
        for (const rank of jutsuRanks) {
            if (playerLevel >= rankLevelRequirements[rank]) {
                const rankData = rankValues[rank];
                
                // Calcular progresso dentro do tier deste rank
                const levelInTier = Math.min(1, (playerLevel - rankLevelRequirements[rank]) / 20);
                
                // Calcular custo de chakra com base no nível e rank
                const chakraCost = Math.round(rankData.chakraCostBase + (playerLevel * rankData.chakraCostScale));
                
                // Calcular dano com base no nível e rank
                const damage = Math.round(
                    rankData.damageInitial + 
                    (rankData.damageFinal - rankData.damageInitial) * levelInTier
                );
                
                // Calcular dano de postura
                const postureDamage = Math.round(
                    rankData.postureDamageInitial + 
                    (rankData.postureDamageFinal - rankData.postureDamageInitial) * levelInTier
                );
                
                // Calcular cooldown
                const cooldown = (
                    rankData.cooldownMin + 
                    (rankData.cooldownMax - rankData.cooldownMin) * levelInTier
                ).toFixed(1);
                
                // Calcular alcance
                const range = Math.round(
                    rankData.rangeMin + 
                    (rankData.rangeMax - rankData.rangeMin) * levelInTier
                );
                
                // Adicionar entrada para este nível e rank
                jutsuTable.push([
                    playerLevel,
                    rank,
                    chakraCost,
                    damage,
                    postureDamage,
                    cooldown,
                    range
                ]);
            }
        }
    }
    
    return jutsuTable;
}

const playerStatusTable = generatePlayerStatusTable(10, 1000, 10, 10, 1000);
console.table(playerStatusTable);

const playerDamageTable = generatePlayerDamageTable(playerStatusTable);
console.table(playerDamageTable);

const enemyTypes = ["Weak", "Medium", "Mini-Boss", "Boss"];

enemyTypes.forEach(enemyType => {
    const enemyBalancingTable = generateEnemyBalancingTable(playerStatusTable, enemyType);
    console.table(enemyBalancingTable);
});

// Gerar e mostrar a tabela de balanceamento de jutsus
const jutsuBalancingTable = generateJutsuBalancingTable(playerStatusTable);
console.table(jutsuBalancingTable);